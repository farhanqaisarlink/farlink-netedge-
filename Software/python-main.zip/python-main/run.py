"""FarLink Agent Launcher."""
import os
import sys

# Ensure python directory is in path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    if "--show-identity" in sys.argv:
        from app.database import Database
        from app.config import config
        from app.device_identity import DeviceIdentity
        db = Database(config.db_path)
        identity = DeviceIdentity(db)
        print("=" * 45)
        print("FARLINK DEVICE IDENTITY")
        print("=" * 45)
        print(f"Device UUID : {identity.device_uuid}")
        print(f"Claim Code  : {identity.claim_code}")
        print(f"MAC Address : {identity.mac_address}")
        print(f"Status      : {identity.get_status()}")
        print("=" * 45)
        sys.exit(0)

    from app.main import main
    main()
