"""Main entry point for FarLink Agent."""
import os
import sys
import time
import signal
import threading
from typing import Dict, Any, Optional
from app.config import config
from app.logger import setup_logger
from app.database import Database
from app.device_identity import DeviceIdentity
from app.api_client import ApiClient
from app.auth import AuthManager
from app.health_monitor import HealthMonitor
from app.heartbeat import HeartbeatWorker
from app.config_manager import ConfigManager
from app.command_worker import CommandWorker
from app.sync_manager import SyncManager
from app.test_runner import TestRunner
from app.lcd_display import LCDDisplay
from app.button_handler import ButtonHandler
from app.network_diagnostics import NetworkDiagnostics
from app.cli_display import CLIDisplay
from app.led_indicator import LEDIndicator

logger = setup_logger("agent_main", log_file=config.log_path)


class FarlinkAgent:
    def __init__(self, force_new_identity: bool = False):
        logger.info("Initializing FarLink Agent...")
        self.db = Database(config.db_path)
        self.identity = DeviceIdentity(self.db, force_new=force_new_identity)
        self.api_client = ApiClient(config.api_url, timeout=config.http_timeout)
        self.api_client.set_device_uuid(self.identity.device_uuid)
        self.auth = AuthManager(self.api_client, self.identity)
        self.health = HealthMonitor()
        self.test_runner = TestRunner()
        self.sync_manager = SyncManager(self.db, self.api_client, identity=self.identity)
        self.config_manager = ConfigManager(self.db, self.api_client)
        self.lcd = LCDDisplay()

        # Remote command worker (polling every 3s for snappy remote responsiveness)
        self.command_worker = CommandWorker(self.api_client, self.db, poll_interval=3, identity=self.identity)
        self._register_commands()

        # Heartbeat worker
        self.heartbeat_worker = HeartbeatWorker(
            api_client=self.api_client,
            identity=self.identity,
            health_monitor=self.health,
            interval=config.heartbeat_interval,
        )

        # Hardware buttons
        self.button_handler = ButtonHandler(
            pin_start=config.pin_start,
            pin_reset=config.pin_reset,
            on_start_press=self.on_start_button,
            on_reset_press=self.on_reset_button,
        )

        # Hardware LED Indicator (GPIO 26, active LOW)
        self.led = LEDIndicator(pin=config.pin_led, active_low=True)

        cfg = self.config_manager.active_config
        env_type = config.device_type
        env_mode = config.device_mode
        if env_type == "FarLink Go":
            self.device_type = "FarLink Go"
            self.device_mode = "Standalone"
            self.master_ip = None
        else:
            self.device_type = cfg.get("type") or cfg.get("device_type") or env_type
            self.device_mode = cfg.get("mode") or cfg.get("device_mode") or env_mode
            self.master_ip = cfg.get("master_ip") or os.getenv("FARLINK_MASTER_IP")

        # Sanitize master_ip: never target self or loopback
        if self.master_ip and NetworkDiagnostics.is_loopback_or_self(self.master_ip):
            logger.warning(f"Configured master_ip {self.master_ip} is self/loopback. Discarding.")
            self.master_ip = None

        self.master_connected: bool = False
        self.master_latency_ms: Optional[float] = None
        if self.master_ip:
            self.heartbeat_worker.master_ip = self.master_ip

        self.iperf_server_proc = None
        if self.device_type == "FarLink Edge" and self.device_mode == "Slave":
            logger.info("FarLink Edge Slave mode detected. Starting background iPerf3 server...")
            self.iperf_server_proc = self.test_runner.iperf.start_server_process()

        self.server_connected: bool = False
        self._consecutive_probe_failures: int = 0
        self._test_lock = threading.Lock()
        self._is_test_running: bool = False
        self._cancel_test_event = threading.Event()
        self._status_override: Optional[str] = None
        self._status_override_color: Optional[str] = None
        self.latest_notification: str = f"Initializing {self.device_type} Agent ({self.device_mode})..."
        self.running = True
        self.last_synced_log_id: int = self.db.get_latest_agent_log_id()

    def _check_master_connectivity(self) -> None:
        """Probe connectivity to FarLink Go Master when running in Slave mode."""
        if self.device_mode != "Slave":
            return

        cfg_master = self.config_manager.active_config.get("master_ip") or os.getenv("FARLINK_MASTER_IP")
        if cfg_master:
            self.master_ip = cfg_master
        elif not self.master_ip:
            gw = NetworkDiagnostics.get_default_gateway()
            if gw:
                self.master_ip = gw

        if self.master_ip:
            diag = NetworkDiagnostics.ping_latency(self.master_ip)
            lat = diag.get("latency_ms")
            self.master_connected = bool(lat is not None and lat < 900)
            self.master_latency_ms = lat
            self.heartbeat_worker.master_ip = self.master_ip
            self.heartbeat_worker.master_connected = self.master_connected
            self.heartbeat_worker.master_latency_ms = lat

    def _apply_config_updates(self) -> None:
        """Apply active config updates to running workers."""
        cfg = self.config_manager.active_config
        hb_interval = int(cfg.get("heartbeat_interval", config.heartbeat_interval))
        self.heartbeat_worker.set_interval(hb_interval)
        self.heartbeat_worker.config_version = self.config_manager.get_active_version()

        # Update dynamic device type and mode from remote configuration
        new_type = cfg.get("type") or cfg.get("device_type")
        new_mode = cfg.get("mode") or cfg.get("device_mode")
        if config.device_type == "FarLink Go":
            self.device_type = "FarLink Go"
            self.device_mode = "Standalone"
            self.master_ip = None
        else:
            if new_type:
                self.device_type = new_type
            if new_mode:
                self.device_mode = new_mode
            if "master_ip" in cfg:
                cand = cfg.get("master_ip")
                self.master_ip = None if NetworkDiagnostics.is_loopback_or_self(cand) else cand
                self.heartbeat_worker.master_ip = self.master_ip
                self._check_master_connectivity()

        # Manage iPerf3 server daemon if mode switched
        if self.device_type == "FarLink Edge" and self.device_mode == "Slave":
            if not self.iperf_server_proc:
                logger.info("FarLink Edge Slave active: starting iPerf3 server daemon...")
                self.iperf_server_proc = self.test_runner.iperf.start_server_process()
        else:
            if self.iperf_server_proc:
                logger.info("Stopping iPerf3 server daemon (device is no longer Edge Slave)...")
                try:
                    self.iperf_server_proc.terminate()
                except Exception:
                    pass
                self.iperf_server_proc = None

    def _sync_config_command(self, payload: Dict[str, Any]) -> bool:
        logger.info("SYNC_CONFIG command received from web")
        if self.config_manager.fetch_and_sync():
            self._apply_config_updates()
        return True

    def _sync_data_command(self, payload: Dict[str, Any]) -> bool:
        logger.info("SYNC_DATA command received from web: syncing local SQLite test results")
        self.lcd.update_dashboard(status_text="Syncing Data...", status_color="#38bdf8")
        synced = self.sync_manager.sync_pending()
        self._sync_sqlite_logs()
        self.latest_notification = f"Data sync complete: {synced} test results synced to cloud."
        self.lcd.update_dashboard(status_text="Data Synced", status_color="#22c55e")
        logger.info(f"SYNC_DATA completed: {synced} test results synced to web")
        return True

    def _upload_log_command(self, payload: Dict[str, Any]) -> bool:
        logger.info("UPLOAD_LOG command received from web: querying local SQLite agent_logs")
        try:
            limit = int(payload.get("limit", 100)) if payload else 100
            sqlite_logs = self.db.get_agent_logs(limit=limit)
            self.api_client.post("agent/logs", json={
                "device_uuid": self.identity.device_uuid,
                "level": "INFO",
                "logs": sqlite_logs,
                "source": "sqlite_agent_logs",
                "count": len(sqlite_logs),
            })
            if sqlite_logs:
                self.last_synced_log_id = max(r["id"] for r in sqlite_logs)
            logger.info(f"Successfully uploaded {len(sqlite_logs)} SQLite log records to web")
            return True
        except Exception as e:
            logger.warning(f"Failed to upload SQLite logs: {e}")
            return False

    def _sync_sqlite_logs(self, limit: int = 50) -> None:
        """Scheduled synchronization of new SQLite logs to web."""
        try:
            sqlite_logs = self.db.get_agent_logs(limit=limit, since_id=self.last_synced_log_id)
            if sqlite_logs:
                resp = self.api_client.post("agent/logs", json={
                    "device_uuid": self.identity.device_uuid,
                    "level": "INFO",
                    "logs": sqlite_logs,
                    "source": "sqlite_agent_logs",
                    "count": len(sqlite_logs),
                })
                if resp and resp.status_code in (200, 201):
                    self.last_synced_log_id = max(r["id"] for r in sqlite_logs)
                    logger.debug(f"Synced {len(sqlite_logs)} SQLite log records to web")
        except Exception as e:
            logger.debug(f"Scheduled log sync deferred: {e}")

    def _restart_agent_command(self, payload: Dict[str, Any]) -> bool:
        logger.info("RESTART_AGENT command received: scheduling restart")
        self.latest_notification = "Agent restart requested from web. Restarting..."
        self.lcd.update_dashboard(status_text="Restarting...", status_color="#f59e0b")
        def _delayed_stop():
            import time
            import os
            import subprocess
            import platform
            time.sleep(2.0)
            logger.info("Restarting agent process...")
            self.shutdown()
            if platform.system() == "Linux":
                try:
                    cmd = ["systemctl", "restart", "farlink-agent"] if os.geteuid() == 0 else ["sudo", "-n", "systemctl", "restart", "farlink-agent"]
                    subprocess.run(cmd, timeout=5)
                except Exception:
                    pass
            os._exit(0)
        import threading
        threading.Thread(target=_delayed_stop, daemon=True).start()
        return True

    def _reboot_device_command(self, payload: Dict[str, Any]) -> bool:
        logger.info("REBOOT_DEVICE command received from web: scheduling system reboot")
        self.latest_notification = "System reboot requested via Web. Rebooting now..."
        self.lcd.update_dashboard(status_text="Rebooting...", status_color="#ef4444")
        def _delayed_reboot():
            import time
            import os
            import subprocess
            import platform
            time.sleep(2.0)
            logger.info("Executing system reboot...")
            self.shutdown()
            if platform.system() == "Linux":
                try:
                    cmd = ["reboot"] if os.geteuid() == 0 else ["sudo", "-n", "reboot"]
                    subprocess.run(cmd, timeout=5)
                except Exception:
                    pass
            os._exit(0)
        import threading
        threading.Thread(target=_delayed_reboot, daemon=True).start()
        return True

    def _register_commands(self) -> None:
        self.command_worker.register_handler("SYNC_CONFIG", self._sync_config_command)
        self.command_worker.register_handler("RUN_TEST", lambda p: self.run_test_command(p))
        self.command_worker.register_handler("SYNC_DATA", self._sync_data_command)
        self.command_worker.register_handler("UPLOAD_LOG", self._upload_log_command)
        self.command_worker.register_handler("RESTART_AGENT", self._restart_agent_command)
        self.command_worker.register_handler("REBOOT_DEVICE", self._reboot_device_command)

    def _render_dashboard(
        self,
        last_test: Optional[Dict[str, Any]] = None,
        test_running: bool = False,
        suppress_test_status: bool = False,
    ) -> None:
        """Render and continuously maintain GUI on LCD/Framebuffer and terminal."""
        try:
            pending_count = self.sync_manager.get_pending_count()
            diag = NetworkDiagnostics.run_full_diagnostics()
            conn = diag.get("connection_type") or NetworkDiagnostics.get_connection_type()

            is_running = test_running or self._is_test_running
            if is_running:
                status_text = "Testing..."
                status_color = "#38bdf8"
                # Keep current active test readings (or blank), do NOT show old completed numbers
                dl = self.lcd.last_dl
                ul = self.lcd.last_ul
                lat = self.lcd.last_ping
                jit = self.lcd.last_jitter
                rtc_t = None
            elif suppress_test_status or (self._status_override and self._status_override in ("Online", "Offline", "Ready", "Resetting...", "Cancelled")):
                status_text = self._status_override or ("Online" if self.server_connected else "Offline")
                status_color = self._status_override_color or ("#22c55e" if self.server_connected else "#f59e0b")
                dl = self.lcd.last_dl
                ul = self.lcd.last_ul
                lat = self.lcd.last_ping or diag.get("internet_latency_ms")
                jit = self.lcd.last_jitter or diag.get("jitter_ms")
                rtc_t = None
            else:
                if last_test is None:
                    last_test = self.db.get_latest_test_result()

                if last_test:
                    dl = last_test.get("download_mbps")
                    ul = last_test.get("upload_mbps")
                    lat = last_test.get("latency_ms")
                    jit = last_test.get("jitter_ms")
                    rtc_t = last_test.get("rtc_time") or last_test.get("finished_at")
                    status_text = "Test complete" if last_test.get("status") == "success" else "Test failed"
                    status_color = "#22c55e" if last_test.get("status") == "success" else "#ef4444"
                elif self.server_connected:
                    dl = None
                    ul = None
                    lat = diag.get("internet_latency_ms")
                    jit = diag.get("jitter_ms")
                    rtc_t = None
                    status_text = "Ready"
                    status_color = "#22c55e"
                else:
                    dl = None
                    ul = None
                    lat = diag.get("internet_latency_ms")
                    jit = diag.get("jitter_ms")
                    rtc_t = None
                    status_text = "Offline"
                    status_color = "#f59e0b"

            # 1. ALWAYS redraw and maintain the graphical GUI on LCD / Framebuffer
            self.lcd.update_dashboard(
                dl_mbps=dl,
                ul_mbps=ul,
                latency_ms=lat,
                jitter_ms=jit,
                device_code=self.identity.claim_code,
                status_text=status_text,
                status_color=status_color,
                conn_type=conn.get("type", "Ethernet"),
                rtc_time=rtc_t,
            )

            # 2. Render CLI
            CLIDisplay.render(
                identity=self.identity,
                health=self.health,
                db=self.db,
                active_config=self.config_manager.active_config,
                api_url=config.api_url,
                last_test=last_test if not is_running else None,
                test_running=is_running,
                server_connected=self.server_connected,
                notification=self.latest_notification,
                pending_sync_count=pending_count,
                master_ip=self.master_ip,
                master_connected=self.master_connected,
                master_latency_ms=self.master_latency_ms,
                suppress_console=self.lcd.is_hardware_available,
            )
        except Exception as e:
            logger.debug(f"Display render error: {e}")

    def run_benchmark(self, trigger_type: str = "scheduled", server_ip: Optional[str] = None) -> bool:
        """Unified test execution with trigger tracking ('button', 'remote', 'scheduled') and failure recording."""
        if not self._test_lock.acquire(blocking=False):
            logger.info("Test already in progress. Ignoring duplicate trigger.")
            return False

        try:
            self._is_test_running = True
            self._cancel_test_event.clear()
            self._status_override = None
            self.led.start_blinking()
            logger.info(f"Benchmark test triggered (trigger_type: {trigger_type}) - starting fresh test cycle")
            self.latest_notification = f"Running diagnostic test ({trigger_type})... Please wait."
            conn = NetworkDiagnostics.get_connection_type()

            # Reset display immediately: clear download and upload to show fresh test in progress
            self.lcd.last_dl = None
            self.lcd.last_ul = None
            self.lcd.last_ping = None
            self.lcd.last_jitter = None
            self.lcd.update_dashboard(
                dl_mbps=None,
                ul_mbps=None,
                latency_ms=None,
                jitter_ms=None,
                device_code=self.identity.claim_code,
                status_text="Testing...",
                status_color="#38bdf8",
                conn_type=conn.get("type", "Ethernet"),
            )
            self._render_dashboard(test_running=True)

            def _on_progress(stage: str, data: Dict[str, Any]) -> None:
                if self._cancel_test_event.is_set():
                    return
                if stage == "ping":
                    lat = data.get("latency_ms")
                    jit = data.get("jitter_ms")
                    self.lcd.update_dashboard(
                        latency_ms=lat,
                        jitter_ms=jit,
                        status_text="Testing DL...",
                        status_color="#38bdf8",
                    )
                elif stage == "download_done":
                    dl = data.get("download_mbps")
                    self.lcd.update_dashboard(
                        dl_mbps=dl,
                        status_text="Testing UL...",
                        status_color="#38bdf8",
                    )
                elif stage == "upload_done":
                    ul = data.get("upload_mbps")
                    self.lcd.update_dashboard(
                        ul_mbps=ul,
                        status_text="Finalizing...",
                        status_color="#38bdf8",
                    )

            active_cfg = self.config_manager.active_config
            if self.device_type == "FarLink Edge" and self.master_ip and not NetworkDiagnostics.is_loopback_or_self(self.master_ip):
                duration = int(active_cfg.get("iperf_duration", 5))
                streams = int(active_cfg.get("iperf_streams", 1))
                target_master = server_ip or self.master_ip
                result = self.test_runner.run_edge_dual_test(
                    master_ip=target_master,
                    iperf_duration=duration,
                    iperf_streams=streams,
                    trigger_type=trigger_type,
                    progress_callback=_on_progress,
                    cancel_check=lambda: self._cancel_test_event.is_set(),
                )
            else:
                # FarLink Go (or standalone): execute real internet speed test
                result = self.test_runner.run_speed_test(
                    server_ip=server_ip,
                    trigger_type=trigger_type,
                    progress_callback=_on_progress,
                    cancel_check=lambda: self._cancel_test_event.is_set(),
                )

            # Check if user cancelled
            if self._cancel_test_event.is_set() or result.get("status") == "cancelled":
                logger.info("Test cancelled before completion.")
                self.latest_notification = "Test was stopped / cancelled by user."
                self._status_override = "Cancelled"
                self._status_override_color = "#f59e0b"
                self.lcd.update_dashboard(
                    status_text="Cancelled",
                    status_color="#f59e0b",
                )
                return False

            result["connection_type"] = conn.get("type", "Ethernet")
            result["interface"] = conn.get("interface", "eth0")
            self.sync_manager.enqueue_result(result)

            # Try syncing if online
            synced = self.sync_manager.sync_pending()
            self.server_connected = self.api_client.is_connected
            pending_cnt = self.sync_manager.get_pending_count()

            status_str = result.get("status", "success")
            final_status_text = "Test complete" if status_str == "success" else "Test failed"
            final_status_color = "#22c55e" if status_str == "success" else "#ef4444"
            self._status_override = final_status_text
            self._status_override_color = final_status_color

            if status_str == "failed":
                self.latest_notification = f"Test failed: {result.get('error_message', 'Error')}. Saved locally."
            elif self.server_connected:
                self.latest_notification = f"Test finished ({trigger_type}). Synced with cloud."
            else:
                self.latest_notification = f"Test finished ({trigger_type}). Saved locally ({pending_cnt} queued)."

            self.heartbeat_worker.last_test_at = result["finished_at"]
            self.lcd.show_test_result(
                dl_mbps=result.get("download_mbps"),
                ul_mbps=result.get("upload_mbps"),
                latency=result.get("latency_ms"),
                jitter=result.get("jitter_ms"),
                device_code=self.identity.claim_code,
                status_text=final_status_text,
                conn_type=conn.get("type", "Ethernet"),
            )
            self._render_dashboard(last_test=result, test_running=False)
            return True
        finally:
            self._is_test_running = False
            self.led.off()
            try:
                self._test_lock.release()
            except RuntimeError:
                pass

    def on_start_button(self) -> None:
        """Physical Push Button (GPIO 5) Start/Stop toggle callback."""
        if self._is_test_running:
            logger.info("Physical Start/Stop button pressed while test running -> STOPPING test!")
            self._cancel_test_event.set()
            self.led.off()
            self.latest_notification = "Test cancelled by physical stop button."
            self._status_override = "Cancelled"
            self._status_override_color = "#f59e0b"
            self.lcd.update_dashboard(
                status_text="Cancelled",
                status_color="#f59e0b",
            )
            return

        logger.info("Physical Start button pressed -> STARTING benchmark test from fresh state!")
        self._is_test_running = True
        self._cancel_test_event.clear()
        self._status_override = None
        threading.Thread(target=lambda: self.run_benchmark(trigger_type="button"), daemon=True).start()

    def on_reset_button(self) -> None:
        """Physical Reset Button (GPIO 6) handler: re-evaluates network and resets dashboard."""
        logger.info("Physical Reset button pressed (GPIO 6): Re-evaluating network diagnostics & resetting display metrics.")
        if self._is_test_running:
            self._cancel_test_event.set()
            self.led.off()

        # 1. Reset metrics display back to fresh state
        self.lcd.last_dl = None
        self.lcd.last_ul = None
        self.lcd.last_ping = None
        self.lcd.last_jitter = None
        self.latest_notification = "Hardware reset initiated. Re-probing network & server..."
        conn = NetworkDiagnostics.get_connection_type()

        self.lcd.update_dashboard(
            dl_mbps=None,
            ul_mbps=None,
            status_text="Resetting...",
            status_color="#f59e0b",
            conn_type=conn.get("type", "Ethernet"),
        )
        self.led.off()

        # 2. Run fresh network diagnostics
        diag = NetworkDiagnostics.run_full_diagnostics()
        self.server_connected = self.api_client.check_connection(timeout=3)
        conn = diag.get("connection_type") or NetworkDiagnostics.get_connection_type()

        status_text = "Online" if self.server_connected else "Offline"
        status_color = "#22c55e" if self.server_connected else "#f59e0b"
        self._status_override = status_text
        self._status_override_color = status_color

        self.lcd.update_dashboard(
            dl_mbps=None,
            ul_mbps=None,
            latency_ms=diag.get("internet_latency_ms"),
            jitter_ms=diag.get("jitter_ms"),
            device_code=self.identity.claim_code,
            status_text=status_text,
            status_color=status_color,
            conn_type=conn.get("type", "Ethernet"),
        )
        self.latest_notification = f"Reset complete. Network: {conn.get('type', 'Ethernet')} ({status_text})."
        self._render_dashboard(suppress_test_status=True)

    def run_test_command(self, payload: Dict[str, Any]) -> bool:
        """Remote test trigger from FarLink Cloud dashboard."""
        server_ip = payload.get("server_ip") if payload else None
        logger.info("Executing RUN_TEST triggered from FarLink Cloud web dashboard")
        return self.run_benchmark(trigger_type="remote", server_ip=server_ip)

    def start(self) -> None:
        logger.info(f"Agent Hardware Serial Number: {self.identity.serial_number}")
        logger.info(f"Agent Device UUID: {self.identity.device_uuid}")
        logger.info(f"Agent Claim Code: {self.identity.claim_code}")

        # Check server connection on startup
        self.server_connected = self.api_client.check_connection(timeout=2)
        if self.server_connected:
            self.latest_notification = f"Connected to FarLink Server (SN: {self.identity.serial_number}). Synchronizing..."
            self.auth.register_device()
        else:
            self.latest_notification = "Server disconnected. Operating in offline standalone mode."
            logger.info("[OFFLINE] Operating in standalone offline mode. All metrics stored locally.")

        # Real initial network diagnostics and connection detection
        diag = NetworkDiagnostics.run_full_diagnostics()
        conn = diag.get("connection_type") or NetworkDiagnostics.get_connection_type()
        last_test = self.db.get_latest_test_result()

        dl_mbps = last_test.get("download_mbps") if last_test else None
        ul_mbps = last_test.get("upload_mbps") if last_test else None
        lat = last_test.get("latency_ms") if last_test else diag.get("internet_latency_ms")
        jit = last_test.get("jitter_ms") if last_test else diag.get("jitter_ms")

        self.lcd.update_dashboard(
            dl_mbps=dl_mbps,
            ul_mbps=ul_mbps,
            latency_ms=lat,
            jitter_ms=jit,
            device_code=self.identity.claim_code,
            status_text="Ready" if self.server_connected else "Offline",
            status_color="#22c55e" if self.server_connected else "#f59e0b",
            conn_type=conn.get("type", "Ethernet"),
        )

        # Start workers
        self.heartbeat_worker.start()
        self.command_worker.start()

        # Check for remote config on boot if connected
        if self.server_connected and self.config_manager.fetch_and_sync():
            self._apply_config_updates()

        # Initial dashboard render
        self._check_master_connectivity()
        self._render_dashboard(last_test=last_test)

        # Trigger automatic initial test so download & upload appear on startup without needing button press
        threading.Thread(target=lambda: self.run_benchmark(trigger_type="scheduled"), daemon=True).start()

        sync_counter = 0
        test_counter = 0
        connection_check_counter = 0
        master_check_counter = 0

        while self.running:
            try:
                time.sleep(3)
                sync_counter += 3
                test_counter += 3
                connection_check_counter += 3
                master_check_counter += 3

                # Periodically probe master reachability in Slave mode
                if master_check_counter >= 6:
                    self._check_master_connectivity()
                    master_check_counter = 0

                # Periodically probe server status with hysteresis
                if connection_check_counter >= 15:
                    prev_state = self.server_connected
                    probe_ok = self.api_client.check_connection(timeout=5)
                    if probe_ok:
                        self._consecutive_probe_failures = 0
                        self.server_connected = True
                    else:
                        self._consecutive_probe_failures += 1
                        if self._consecutive_probe_failures >= 2:
                            self.server_connected = False
                    connection_check_counter = 0

                    # Detect transition from offline -> online
                    if not prev_state and self.server_connected:
                        logger.info("[RECONNECTED] Server connection restored. Synchronizing queued data...")
                        self.auth.register_device()
                        synced = self.sync_manager.sync_pending()
                        self._sync_sqlite_logs()
                        if self.config_manager.fetch_and_sync():
                            self._apply_config_updates()
                        self.latest_notification = f"Server reconnected! {synced} test results automatically synced."

                active_cfg = self.config_manager.active_config
                sync_interval = int(active_cfg.get("sync_interval", 60))
                # Selectable test intervals: 15 minutes (900s), 1 hour (3600s), 24 hours (86400s)
                test_interval = int(active_cfg.get("scheduled_interval") or active_cfg.get("test_interval") or 900)

                # 1. Sync pending results & logs with cloud
                if not self.auth.is_authenticated() and self.server_connected and sync_counter % 12 == 0:
                    if self.auth.register_device():
                        self.latest_notification = f"Registered & authenticated with FarLink Cloud! Token received."
                        logger.info("[REGISTERED] Device successfully registered by admin in dashboard.")

                if sync_counter >= sync_interval:
                    if self.server_connected and self.auth.is_authenticated():
                        self.sync_manager.sync_pending()
                        self._sync_sqlite_logs()
                        if self.config_manager.fetch_and_sync():
                            self._apply_config_updates()
                    sync_counter = 0

                # 2. Trigger automated periodic benchmark test per configured test_interval
                if test_counter >= test_interval:
                    if not self._is_test_running:
                        logger.info(f"[AUTO BENCHMARK] Scheduled interval reached ({test_interval}s). Running auto benchmark...")
                        threading.Thread(target=lambda: self.run_benchmark(trigger_type="scheduled"), daemon=True).start()
                    test_counter = 0

                # Live periodic refresh
                self._render_dashboard()
            except KeyboardInterrupt:
                break

        self.shutdown()

    def stop(self) -> None:
        self.running = False

    def shutdown(self) -> None:
        logger.info("Shutting down FarLink Agent...")
        self.running = False
        self.heartbeat_worker.stop()
        self.command_worker.stop()
        self.button_handler.cleanup()
        self.led.cleanup()
        if getattr(self, "iperf_server_proc", None):
            try:
                self.iperf_server_proc.terminate()
                self.iperf_server_proc = None
            except Exception:
                pass
        logger.info("FarLink Agent shutdown complete.")


def handle_signals(agent: FarlinkAgent):
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}. Terminating...")
        agent.stop()
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)


def main(force_new_identity: bool = False):
    if "--new-identity" in sys.argv or "--reset-code" in sys.argv:
        force_new_identity = True
    agent = FarlinkAgent(force_new_identity=force_new_identity)
    handle_signals(agent)
    agent.start()


if __name__ == "__main__":
    main()
