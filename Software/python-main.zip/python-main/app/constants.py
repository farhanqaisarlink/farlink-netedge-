"""Constants and Enums for FarLink Agent."""
from enum import Enum


class DeviceStatus(str, Enum):
    PENDING = "PENDING"
    ACTIVE = "ACTIVE"
    OFFLINE = "OFFLINE"
    DISABLED = "DISABLED"
    REVOKED = "REVOKED"
    ERROR = "ERROR"


class CommandStatus(str, Enum):
    PENDING = "PENDING"
    SENT = "SENT"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    EXPIRED = "EXPIRED"


class SyncStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    SYNCED = "SYNCED"
    FAILED = "FAILED"


class TriggerType(str, Enum):
    BUTTON = "button"
    REMOTE = "remote"
    SCHEDULED = "scheduled"


class TestStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"


# Technical Defaults per GEMINI.md Section 23 & PRD Section 5.3
DEFAULT_HEARTBEAT_INTERVAL = 60
DEFAULT_HTTP_TIMEOUT = 10
DEFAULT_INITIAL_RETRY_DELAY = 2.0
DEFAULT_MAX_RETRIES = 5
DEFAULT_CONFIG_VERSION = 1
DEFAULT_AGENT_VERSION = "1.0.0"

# Selectable test intervals: 15m (900s), 1h (3600s), 24h (86400s)
VALID_TEST_INTERVALS = [900, 3600, 86400]
DEFAULT_SCHEDULED_INTERVAL = 900

# Button GPIO Pins (Active Low)
DEFAULT_PIN_START = 5
DEFAULT_PIN_RESET = 6

# LED Indicator GPIO Pin (Active Low: 0=ON/Blinking, 1=OFF)
DEFAULT_PIN_LED = 26
