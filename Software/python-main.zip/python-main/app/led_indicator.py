"""LED indicator controller for Raspberry Pi GPIO (Active LOW on GPIO 26).

Behavior:
- Blinking while diagnostic/speed tests are running ("Testing...").
- OFF (mati) when test completes ("Test complete"), fails, or device is idle.
- Active LOW logic:
  - Output LOW (0 / False / 0V) -> LED ON.
  - Output HIGH (1 / True / 3.3V) -> LED OFF.
"""
import time
import threading
from typing import Optional
from app.logger import setup_logger
from app.constants import DEFAULT_PIN_LED

logger = setup_logger("led_indicator")


class LEDIndicator:
    def __init__(self, pin: int = DEFAULT_PIN_LED, active_low: bool = True):
        self.pin = pin
        self.active_low = active_low
        self.is_hardware_available = False
        self.active_backend: str = "mock"
        self._led_gz = None
        self._is_blinking = False
        self._blink_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._state_is_on = False  # Track logical ON/OFF state

        self._setup_gpio()

    def _setup_gpio(self) -> None:
        # Tier 1: gpiozero (recommended for Raspberry Pi CM5 / Pi 5 with RP1)
        try:
            from gpiozero import LED
            # In gpiozero, active_high=False maps on() to LOW and off() to HIGH
            self._led_gz = LED(self.pin, active_high=not self.active_low, initial_value=False)
            self.is_hardware_available = True
            self.active_backend = "gpiozero"
            logger.info(f"Hardware LED configured on GPIO {self.pin} using gpiozero (active_low={self.active_low}, initial=OFF)")
            return
        except Exception as e_gz:
            logger.debug(f"gpiozero backend not available for LED: {e_gz}")

        # Tier 2: RPi.GPIO
        try:
            import RPi.GPIO as GPIO
            GPIO.setmode(GPIO.BCM)
            # Active LOW: Initial state HIGH means OFF
            initial_val = GPIO.HIGH if self.active_low else GPIO.LOW
            GPIO.setup(self.pin, GPIO.OUT, initial=initial_val)
            self.is_hardware_available = True
            self.active_backend = "RPi.GPIO"
            logger.info(f"Hardware LED configured on GPIO {self.pin} using RPi.GPIO (active_low={self.active_low}, initial=OFF)")
            return
        except Exception as e_rpi:
            logger.debug(f"RPi.GPIO backend not available for LED: {e_rpi}")

        # Tier 3: Software mock fallback
        self.is_hardware_available = False
        self.active_backend = "mock"
        logger.info(f"GPIO hardware not available on current environment. LED on GPIO {self.pin} ready in software mock mode.")

    def on(self) -> None:
        """Turn LED ON (drives pin LOW when active_low=True)."""
        with self._lock:
            self._state_is_on = True
            if self.active_backend == "gpiozero" and self._led_gz:
                try:
                    self._led_gz.on()
                except Exception as e:
                    logger.debug(f"gpiozero led on error: {e}")
            elif self.active_backend == "RPi.GPIO":
                try:
                    import RPi.GPIO as GPIO
                    GPIO.output(self.pin, GPIO.LOW if self.active_low else GPIO.HIGH)
                except Exception as e:
                    logger.debug(f"RPi.GPIO led on error: {e}")
            else:
                logger.debug(f"[MOCK LED] GPIO {self.pin} -> ON (Active LOW 0V)")

    def off(self) -> None:
        """Turn LED OFF (drives pin HIGH when active_low=True). Stops blinking if active."""
        self.stop_blinking()
        with self._lock:
            self._state_is_on = False
            if self.active_backend == "gpiozero" and self._led_gz:
                try:
                    self._led_gz.off()
                except Exception as e:
                    logger.debug(f"gpiozero led off error: {e}")
            elif self.active_backend == "RPi.GPIO":
                try:
                    import RPi.GPIO as GPIO
                    GPIO.output(self.pin, GPIO.HIGH if self.active_low else GPIO.LOW)
                except Exception as e:
                    logger.debug(f"RPi.GPIO led off error: {e}")
            else:
                logger.debug(f"[MOCK LED] GPIO {self.pin} -> OFF (Active LOW 3.3V)")

    def start_blinking(self, interval: float = 0.25) -> None:
        """Start blinking LED continuously in background thread until stopped."""
        with self._lock:
            if self._is_blinking:
                return
            self._is_blinking = True
            self._stop_event.clear()

        # gpiozero has built-in hardware-timed blink
        if self.active_backend == "gpiozero" and self._led_gz:
            try:
                self._led_gz.blink(on_time=interval, off_time=interval)
                logger.info(f"LED on GPIO {self.pin} blinking started (gpiozero, interval={interval}s)")
                return
            except Exception as e:
                logger.debug(f"gpiozero blink error, falling back to thread: {e}")

        # Threaded blink for RPi.GPIO and Mock
        def _blink_worker():
            logger.info(f"LED on GPIO {self.pin} blinking worker started (interval={interval}s)")
            while not self._stop_event.is_set():
                self.on()
                if self._stop_event.wait(interval):
                    break
                self._raw_off_internal()
                if self._stop_event.wait(interval):
                    break
            self._raw_off_internal()

        self._blink_thread = threading.Thread(target=_blink_worker, daemon=True)
        self._blink_thread.start()

    def _raw_off_internal(self) -> None:
        """Turn pin OFF without stopping the blinking thread state."""
        if self.active_backend == "gpiozero" and self._led_gz:
            try:
                self._led_gz.off()
            except Exception:
                pass
        elif self.active_backend == "RPi.GPIO":
            try:
                import RPi.GPIO as GPIO
                GPIO.output(self.pin, GPIO.HIGH if self.active_low else GPIO.LOW)
            except Exception:
                pass
        self._state_is_on = False

    def stop_blinking(self) -> None:
        """Stop blinking and ensure pin is turned OFF."""
        with self._lock:
            if not self._is_blinking:
                return
            self._is_blinking = False
            self._stop_event.set()

        if self.active_backend == "gpiozero" and self._led_gz:
            try:
                self._led_gz.off()
            except Exception:
                pass

        if self._blink_thread and self._blink_thread.is_alive():
            try:
                self._blink_thread.join(timeout=1.0)
            except Exception:
                pass
            self._blink_thread = None

        self._raw_off_internal()
        logger.info(f"LED on GPIO {self.pin} blinking stopped -> state: OFF")

    @property
    def is_blinking(self) -> bool:
        return self._is_blinking

    @property
    def is_on(self) -> bool:
        return self._state_is_on

    def cleanup(self) -> None:
        """Turn off LED and release GPIO resources."""
        self.stop_blinking()
        self.off()
        if self.active_backend == "gpiozero" and self._led_gz:
            try:
                self._led_gz.close()
            except Exception:
                pass
            self._led_gz = None
        elif self.active_backend == "RPi.GPIO":
            try:
                import RPi.GPIO as GPIO
                GPIO.cleanup(self.pin)
            except Exception:
                pass
        self.is_hardware_available = False
        logger.info(f"LED on GPIO {self.pin} cleanup complete.")
