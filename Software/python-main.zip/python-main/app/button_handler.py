"""Physical button handler on Raspberry Pi CM5 / Pi 5 / Pi 4 GPIO with debounce and mock fallback."""
import time
import threading
from typing import Callable, Optional
from app.logger import setup_logger
from app.constants import DEFAULT_PIN_START, DEFAULT_PIN_RESET

logger = setup_logger("button_handler")


class ButtonHandler:
    def __init__(
        self,
        pin_start: int = DEFAULT_PIN_START,
        pin_reset: int = DEFAULT_PIN_RESET,
        on_start_press: Optional[Callable[[], None]] = None,
        on_reset_press: Optional[Callable[[], None]] = None,
    ):
        self.pin_start = pin_start
        self.pin_reset = pin_reset
        self.on_start_press = on_start_press
        self.on_reset_press = on_reset_press
        self.is_hardware_available = False
        self.active_backend: str = "mock"
        self._gpiozero_btns = []
        self._lgpio_handle: Optional[int] = None
        self._lgpio_chip: Optional[int] = None
        self._last_start_press: float = 0.0
        self._last_reset_press: float = 0.0
        self._poll_thread: Optional[threading.Thread] = None
        self._stop_poll = threading.Event()
        self._setup_gpio()

    def _start_polling_thread(self, read_fn: Callable[[int], int]) -> None:
        """Universal background polling thread for active-low buttons."""
        self._stop_poll.clear()

        def _worker():
            last_start_state = 1
            last_reset_state = 1
            while not self._stop_poll.is_set():
                try:
                    s_state = read_fn(self.pin_start)
                    r_state = read_fn(self.pin_reset)

                    # Falling edge detection: 1 -> 0 (Active-LOW: pressed to GND)
                    if last_start_state == 1 and s_state == 0:
                        self._handle_start_event()
                    last_start_state = s_state

                    if last_reset_state == 1 and r_state == 0:
                        self._handle_reset_event()
                    last_reset_state = r_state
                except Exception as e:
                    logger.debug(f"Button poll error: {e}")
                time.sleep(0.025)  # 25ms poll cycle (40Hz, snappy, near-zero CPU)

        self._poll_thread = threading.Thread(target=_worker, daemon=True, name="ButtonPollThread")
        self._poll_thread.start()

    def _setup_gpio(self) -> None:
        # Tier 1: lgpio (Native Linux kernel 6.x / Raspberry Pi CM5 & Pi 5 with RP1 chip on gpiochip4)
        try:
            import lgpio

            for chip_num in [4, 0, 1, 2, 3]:
                try:
                    handle = lgpio.gpiochip_open(chip_num)
                    if handle is not None and handle >= 0:
                        self._lgpio_handle = handle
                        self._lgpio_chip = chip_num
                        break
                except Exception:
                    continue

            if self._lgpio_handle is not None and self._lgpio_handle >= 0:
                claimed = False
                try:
                    # Direct alert claim with internal pull-up (Active-LOW: press connects pin to GND)
                    lgpio.gpio_claim_alert(self._lgpio_handle, self.pin_start, lgpio.FALLING_EDGE, lgpio.SET_PULL_UP)
                    lgpio.gpio_claim_alert(self._lgpio_handle, self.pin_reset, lgpio.FALLING_EDGE, lgpio.SET_PULL_UP)

                    def _lgpio_start_cb(chip, gpio, level, tick):
                        if level == 0:
                            self._handle_start_event()

                    def _lgpio_reset_cb(chip, gpio, level, tick):
                        if level == 0:
                            self._handle_reset_event()

                    lgpio.callback(self._lgpio_handle, self.pin_start, lgpio.FALLING_EDGE, _lgpio_start_cb)
                    lgpio.callback(self._lgpio_handle, self.pin_reset, lgpio.FALLING_EDGE, _lgpio_reset_cb)
                    # Also launch polling thread as backup to ensure no missed edges on CM5/Pi5
                    self._start_polling_thread(read_fn=lambda pin: lgpio.gpio_read(self._lgpio_handle, pin))
                    claimed = True
                    self.active_backend = "lgpio_alert_poll"
                    logger.info(
                        f"Hardware GPIO buttons configured on pins {self.pin_start} (start/stop) & {self.pin_reset} (reset) using lgpio alert+poll on chip {self._lgpio_chip}"
                    )
                except Exception as e_alert:
                    logger.debug(f"lgpio alert claim failed ({e_alert}), falling back to lgpio input polling...")
                    try:
                        lgpio.gpio_claim_input(self._lgpio_handle, self.pin_start, lgpio.SET_PULL_UP)
                        lgpio.gpio_claim_input(self._lgpio_handle, self.pin_reset, lgpio.SET_PULL_UP)
                        self._start_polling_thread(read_fn=lambda pin: lgpio.gpio_read(self._lgpio_handle, pin))
                        claimed = True
                        self.active_backend = "lgpio_poll"
                        logger.info(
                            f"Hardware GPIO buttons configured on pins {self.pin_start} & {self.pin_reset} using lgpio polling on chip {self._lgpio_chip}"
                        )
                    except Exception as e_claim:
                        logger.debug(f"lgpio input claim failed: {e_claim}")

                if claimed:
                    self.is_hardware_available = True
                    return
        except Exception as e_lg:
            logger.debug(f"lgpio backend not available: {e_lg}")

        # Tier 2: gpiozero (official recommendation for Raspberry Pi)
        try:
            from gpiozero import Button

            btn_start = Button(self.pin_start, pull_up=True, bounce_time=0.15)
            btn_reset = Button(self.pin_reset, pull_up=True, bounce_time=0.15)

            btn_start.when_pressed = self._handle_start_event
            btn_reset.when_pressed = self._handle_reset_event

            self._gpiozero_btns = [btn_start, btn_reset]
            self.is_hardware_available = True
            self.active_backend = "gpiozero"
            logger.info(
                f"Hardware GPIO buttons configured on pins {self.pin_start} (start/stop) & {self.pin_reset} (reset) using gpiozero (active-low)"
            )
            return
        except Exception as e_gz:
            logger.debug(f"gpiozero backend not available: {e_gz}")

        # Tier 3: RPi.GPIO (BCM legacy for Pi 3/4)
        try:
            import RPi.GPIO as GPIO

            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.pin_start, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.setup(self.pin_reset, GPIO.IN, pull_up_down=GPIO.PUD_UP)

            self._start_polling_thread(read_fn=lambda pin: GPIO.input(pin))
            self.is_hardware_available = True
            self.active_backend = "RPi.GPIO"
            logger.info(
                f"Hardware GPIO buttons configured on pins {self.pin_start} (start/stop) & {self.pin_reset} (reset) using RPi.GPIO"
            )
            return
        except Exception as e_rpi:
            logger.debug(f"RPi.GPIO backend not available: {e_rpi}")

        # Tier 4: Software mock fallback
        self.is_hardware_available = False
        self.active_backend = "mock"
        logger.info(
            f"GPIO hardware not detected. Buttons {self.pin_start} & {self.pin_reset} running in mock mode."
        )

    def _handle_start_event(self, *args) -> None:
        now = time.time()
        if now - self._last_start_press < 0.35:
            logger.debug("Debounce: start/stop button event ignored")
            return
        self._last_start_press = now
        logger.info(f"Physical Start/Stop button pressed (GPIO {self.pin_start})")
        if self.on_start_press:
            try:
                self.on_start_press()
            except Exception as e:
                logger.error(f"Error executing on_start_press: {e}")

    def _handle_reset_event(self, *args) -> None:
        now = time.time()
        if now - self._last_reset_press < 0.35:
            logger.debug("Debounce: reset button event ignored")
            return
        self._last_reset_press = now
        logger.info(f"Physical Reset button pressed (GPIO {self.pin_reset})")
        if self.on_reset_press:
            try:
                self.on_reset_press()
            except Exception as e:
                logger.error(f"Error executing on_reset_press: {e}")

    def trigger_mock_start(self) -> None:
        """Helper to simulate start button press in development."""
        self._handle_start_event(self.pin_start)

    def trigger_mock_reset(self) -> None:
        """Helper to simulate reset button press in development."""
        self._handle_reset_event(self.pin_reset)

    def cleanup(self) -> None:
        self._stop_poll.set()
        if self._lgpio_handle is not None:
            try:
                import lgpio

                lgpio.gpiochip_close(self._lgpio_handle)
            except Exception:
                pass
            self._lgpio_handle = None
        if self.active_backend == "gpiozero":
            for b in self._gpiozero_btns:
                try:
                    b.close()
                except Exception:
                    pass
            self._gpiozero_btns = []
        elif self.active_backend == "RPi.GPIO":
            try:
                import RPi.GPIO as GPIO

                GPIO.cleanup([self.pin_start, self.pin_reset])
            except Exception:
                pass
        self.is_hardware_available = False
