"""Test runner orchestrating real speed tests, iPerf, and network diagnostics."""
import time
import uuid
import ssl
import urllib.request
from typing import Dict, Any, Optional, Callable
from app.config import config
from app.database import get_utc_now
from app.iperf_runner import IperfRunner
from app.network_diagnostics import NetworkDiagnostics
from app.logger import setup_logger

logger = setup_logger("test_runner")


class TestRunner:
    def __init__(self):
        self.iperf = IperfRunner()
        self._ssl_ctx = ssl._create_unverified_context()

    @staticmethod
    def _is_local_or_loopback(ip_str: Optional[str]) -> bool:
        return NetworkDiagnostics.is_loopback_or_self(ip_str)

    def _measure_http_bandwidth(
        self,
        cancel_check: Optional[Callable[[], bool]] = None,
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ) -> Dict[str, Optional[float]]:
        """Perform real HTTP download and upload bandwidth measurement without dummy numbers."""
        dl_mbps = None
        ul_mbps = None

        if cancel_check and cancel_check():
            return {"download_mbps": None, "upload_mbps": None}

        headers = {
            "User-Agent": "FarLink-Agent/1.0 (Raspberry Pi; Linux)",
            "Accept": "*/*",
        }

        # 1. Measure Real Download from Public CDNs
        dl_targets = [
            "https://speed.cloudflare.com/__down?bytes=5000000",
            "https://proof.ovh.net/files/1Mb.dat",
            "https://speedtest.tele2.net/1MB.zip",
            "https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js",
            "https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js",
        ]

        if progress_callback:
            progress_callback("download_start", {})

        for url in dl_targets:
            if cancel_check and cancel_check():
                return {"download_mbps": None, "upload_mbps": None}
            try:
                req = urllib.request.Request(url, headers=headers)
                t0 = time.time()
                with urllib.request.urlopen(req, context=self._ssl_ctx, timeout=4) as resp:
                    total_bytes = 0
                    while True:
                        if cancel_check and cancel_check():
                            return {"download_mbps": None, "upload_mbps": None}
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        total_bytes += len(chunk)
                        now_el = time.time() - t0
                        if total_bytes >= 2_500_000 and now_el >= 1.0:
                            break

                elapsed = time.time() - t0
                if elapsed > 0.05 and total_bytes > 50000:
                    dl_mbps = round((total_bytes * 8) / (elapsed * 1_000_000), 1)
                    logger.info(f"Real download measured via {url}: {dl_mbps} Mbps ({total_bytes} bytes in {elapsed:.2f}s)")
                    if progress_callback:
                        progress_callback("download_done", {"download_mbps": dl_mbps})
                    break
            except Exception as e:
                logger.debug(f"Download attempt failed on {url}: {e}")

        # 2. Measure Real Upload
        if cancel_check and cancel_check():
            return {"download_mbps": dl_mbps, "upload_mbps": None}

        if progress_callback:
            progress_callback("upload_start", {})

        payload = b"0" * 1_000_000  # 1 MB test payload
        ul_targets = [
            "https://speed.cloudflare.com/__up",
            "https://httpbin.org/post",
        ]

        for url in ul_targets:
            if cancel_check and cancel_check():
                return {"download_mbps": dl_mbps, "upload_mbps": None}
            try:
                req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
                t0 = time.time()
                with urllib.request.urlopen(req, context=self._ssl_ctx, timeout=5) as resp:
                    resp.read(512)
                elapsed = time.time() - t0
                if elapsed > 0.05:
                    ul_mbps = round((len(payload) * 8) / (elapsed * 1_000_000), 1)
                    logger.info(f"Real upload measured via {url}: {ul_mbps} Mbps ({len(payload)} bytes in {elapsed:.2f}s)")
                    if progress_callback:
                        progress_callback("upload_done", {"upload_mbps": ul_mbps})
                    break
            except Exception as e:
                logger.debug(f"Upload attempt failed on {url}: {e}")

        return {"download_mbps": dl_mbps, "upload_mbps": ul_mbps}

    def run_speed_test(
        self,
        server_ip: Optional[str] = None,
        trigger_type: str = "scheduled",
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> Dict[str, Any]:
        """Run network speed test with real measurements and instant cancel check."""
        started_at = get_utc_now()
        start_ts = time.time()
        test_id = str(uuid.uuid4())

        if cancel_check and cancel_check():
            return {
                "id": test_id,
                "test_type": "speedtest",
                "trigger_type": trigger_type,
                "status": "cancelled",
                "error_message": "Test cancelled by user",
                "started_at": started_at,
                "finished_at": started_at,
                "rtc_time": started_at,
                "duration_seconds": 0.0,
                "download_mbps": None,
                "upload_mbps": None,
                "latency_ms": None,
                "jitter_ms": None,
                "packet_loss": 0.0,
            }

        # Guard: never run point-to-point iperf on self/loopback
        use_iperf = bool(server_ip and not self._is_local_or_loopback(server_ip))

        # 1. Run Ping & Jitter measurement first for immediate LCD feedback
        target_host = server_ip if use_iperf else "8.8.8.8"
        diag = NetworkDiagnostics.ping_latency(target_host, count=3)
        latency = diag.get("latency_ms")
        jitter_ms = diag.get("jitter_ms")
        packet_loss = diag.get("loss_percent", 0.0)

        # Fallback to 1.1.1.1 if primary target ping returned None
        if latency is None and not use_iperf:
            diag_fb = NetworkDiagnostics.ping_latency("1.1.1.1", count=2)
            if diag_fb.get("latency_ms") is not None:
                latency = diag_fb.get("latency_ms")
                jitter_ms = diag_fb.get("jitter_ms")
                packet_loss = diag_fb.get("loss_percent", 0.0)

        if progress_callback:
            progress_callback("ping", {"latency_ms": latency, "jitter_ms": jitter_ms})

        if cancel_check and cancel_check():
            return {
                "id": test_id,
                "test_type": "speedtest",
                "trigger_type": trigger_type,
                "status": "cancelled",
                "error_message": "Test cancelled by user",
                "started_at": started_at,
                "finished_at": get_utc_now(),
                "rtc_time": started_at,
                "duration_seconds": round(time.time() - start_ts, 2),
                "download_mbps": None,
                "upload_mbps": None,
                "latency_ms": latency,
                "jitter_ms": jitter_ms,
                "packet_loss": packet_loss,
            }

        download_mbps = None
        upload_mbps = None
        status = "success"
        error_msg = None

        try:
            if use_iperf:
                # Real remote iPerf3 server test
                res = self.iperf.run_client(server_ip=server_ip, duration=5)
                download_mbps = res.get("bandwidth_mbps")
                upload_mbps = download_mbps
                if res.get("jitter_ms") is not None:
                    jitter_ms = res.get("jitter_ms")
                if res.get("packet_loss") is not None:
                    packet_loss = res.get("packet_loss")
                if download_mbps is None and res.get("error"):
                    status = "failed"
                    error_msg = res.get("error")
                if progress_callback:
                    progress_callback("download_done", {"download_mbps": download_mbps})
                    progress_callback("upload_done", {"upload_mbps": upload_mbps})
            else:
                # Standalone real HTTP speed test
                speed = self._measure_http_bandwidth(cancel_check=cancel_check, progress_callback=progress_callback)
                if cancel_check and cancel_check():
                    return {
                        "id": test_id,
                        "test_type": "speedtest",
                        "trigger_type": trigger_type,
                        "status": "cancelled",
                        "error_message": "Test cancelled by user",
                        "started_at": started_at,
                        "finished_at": get_utc_now(),
                        "rtc_time": started_at,
                        "duration_seconds": round(time.time() - start_ts, 2),
                        "download_mbps": None,
                        "upload_mbps": None,
                        "latency_ms": latency,
                        "jitter_ms": jitter_ms,
                        "packet_loss": packet_loss,
                    }
                download_mbps = speed.get("download_mbps")
                upload_mbps = speed.get("upload_mbps")

            # Determine test success vs failure (never drop failed tests!)
            if download_mbps is None and latency is None:
                status = "failed"
                download_mbps = 0.0
                upload_mbps = 0.0
                packet_loss = 100.0
                error_msg = "Complete loss of internet connectivity / connection timeout"
            elif download_mbps is None:
                status = "failed"
                download_mbps = 0.0
                upload_mbps = 0.0
                error_msg = "Throughput test failed — web endpoints unreachable"
        except Exception as e:
            status = "failed"
            download_mbps = 0.0
            upload_mbps = 0.0
            packet_loss = 100.0
            error_msg = str(e)
            logger.error(f"Test execution error: {e}")

        # Quick diagnostic suite (only run if not cancelled, with fast timeouts)
        dns_res = {}
        curl_res = {}
        mtr_res = {}
        ssl_res = {}
        tcp_res = {}
        gw_reachable = True

        if not (cancel_check and cancel_check()):
            try:
                dns_res = NetworkDiagnostics.run_dig("google.com", timeout=2.0)
                curl_res = NetworkDiagnostics.run_curl("https://www.google.com", timeout=3.0)
                tcp_res = NetworkDiagnostics.run_tcp_port_check("8.8.8.8", 443)
                gw_reachable = NetworkDiagnostics.is_gateway_reachable()
                if trigger_type != "button":
                    mtr_res = NetworkDiagnostics.run_mtr(target_host, count=2)
                    ssl_res = NetworkDiagnostics.run_openssl_check("google.com", timeout=2.0)
            except Exception as e_diag:
                logger.debug(f"Quick diagnostic suite non-fatal error: {e_diag}")

        finished_at = get_utc_now()
        conn = NetworkDiagnostics.get_connection_type()

        return {
            "id": test_id,
            "test_type": "iperf" if use_iperf else "speedtest",
            "trigger_type": trigger_type,
            "status": status,
            "error_message": error_msg,
            "started_at": started_at,
            "finished_at": finished_at,
            "rtc_time": started_at,
            "duration_seconds": round(time.time() - start_ts, 2),
            "download_mbps": download_mbps,
            "upload_mbps": upload_mbps,
            "latency_ms": latency,
            "jitter_ms": jitter_ms,
            "packet_loss": packet_loss,
            "dns_latency_ms": dns_res.get("dns_latency_ms"),
            "http_latency_ms": curl_res.get("http_latency_ms"),
            "mtr_hops": mtr_res.get("hops_count"),
            "mtr_max_rtt_ms": mtr_res.get("max_hop_rtt_ms"),
            "ssl_cert_days_remaining": ssl_res.get("days_remaining"),
            "tcp_port_status": tcp_res.get("status"),
            "gateway_reachable": gw_reachable,
            "connection_type": conn.get("type", "Ethernet"),
            "interface": conn.get("interface", "eth0"),
        }

    def run_edge_dual_test(
        self,
        master_ip: Optional[str] = None,
        iperf_duration: int = 5,
        iperf_streams: int = 1,
        trigger_type: str = "scheduled",
        progress_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> Dict[str, Any]:
        """Dual-connection diagnostic for FarLink Edge:
        1. Connection to Master (iPerf3 bandwidth, latency, jitter, packet loss)
        2. Connection to Internet (ping latency, jitter, loss & HTTP bandwidth)
        """
        started_at = get_utc_now()
        start_ts = time.time()
        test_id = str(uuid.uuid4())

        if cancel_check and cancel_check():
            return {
                "id": test_id,
                "test_type": "edge_dual",
                "trigger_type": trigger_type,
                "status": "cancelled",
                "error_message": "Test cancelled by user",
                "started_at": started_at,
                "finished_at": started_at,
                "rtc_time": started_at,
                "duration_seconds": 0.0,
                "download_mbps": None,
                "upload_mbps": None,
                "latency_ms": None,
                "jitter_ms": None,
                "packet_loss": 0.0,
            }

        # Resolve Master target if none provided, but never target self
        target_master = master_ip
        if target_master and self._is_local_or_loopback(target_master):
            logger.warning(f"Target master {target_master} is local/loopback. Discarding.")
            target_master = None

        if not target_master:
            gw = NetworkDiagnostics.get_default_gateway()
            if gw and not self._is_local_or_loopback(gw):
                target_master = gw

        # 1. Measure Connection to Master
        master_conn = {
            "target": target_master,
            "connected": False,
            "latency_ms": None,
            "jitter_ms": None,
            "packet_loss": None,
            "bandwidth_mbps": None,
        }
        if target_master:
            logger.info(f"[EDGE DUAL TEST] Testing Connection 1 (Master: {target_master})...")
            m_ping = NetworkDiagnostics.ping_latency(target_master, count=3)
            master_conn["latency_ms"] = m_ping.get("latency_ms")
            master_conn["jitter_ms"] = m_ping.get("jitter_ms")
            master_conn["packet_loss"] = m_ping.get("loss_percent", 0.0)

            if cancel_check and cancel_check():
                return {
                    "id": test_id,
                    "test_type": "edge_dual",
                    "trigger_type": trigger_type,
                    "status": "cancelled",
                    "error_message": "Test cancelled by user",
                    "started_at": started_at,
                    "finished_at": get_utc_now(),
                    "rtc_time": started_at,
                    "duration_seconds": round(time.time() - start_ts, 2),
                    "download_mbps": None,
                    "upload_mbps": None,
                    "latency_ms": master_conn["latency_ms"],
                    "jitter_ms": master_conn["jitter_ms"],
                    "packet_loss": master_conn["packet_loss"],
                }

            # iPerf3 throughput to Master
            iperf_res = self.iperf.run_client(
                server_ip=target_master,
                duration=iperf_duration,
                streams=iperf_streams
            )
            master_conn["bandwidth_mbps"] = iperf_res.get("bandwidth_mbps")
            if iperf_res.get("jitter_ms") is not None:
                master_conn["jitter_ms"] = iperf_res.get("jitter_ms")
            if iperf_res.get("packet_loss") is not None:
                master_conn["packet_loss"] = iperf_res.get("packet_loss")
            master_conn["connected"] = bool(
                master_conn["latency_ms"] is not None or master_conn["bandwidth_mbps"] is not None
            )

        # 2. Measure Connection to Internet
        if cancel_check and cancel_check():
            return {
                "id": test_id,
                "test_type": "edge_dual",
                "trigger_type": trigger_type,
                "status": "cancelled",
                "error_message": "Test cancelled by user",
                "started_at": started_at,
                "finished_at": get_utc_now(),
                "rtc_time": started_at,
                "duration_seconds": round(time.time() - start_ts, 2),
                "download_mbps": None,
                "upload_mbps": None,
                "latency_ms": None,
                "jitter_ms": None,
                "packet_loss": 0.0,
            }

        logger.info("[EDGE DUAL TEST] Testing Connection 2 (Internet: 8.8.8.8 & Web)...")
        net_ping = NetworkDiagnostics.ping_latency("8.8.8.8", count=3)
        inet_speed = self._measure_http_bandwidth(cancel_check=cancel_check, progress_callback=progress_callback)
        internet_conn = {
            "target": "8.8.8.8",
            "connected": bool(net_ping.get("latency_ms") is not None or inet_speed.get("download_mbps") is not None),
            "latency_ms": net_ping.get("latency_ms"),
            "jitter_ms": net_ping.get("jitter_ms"),
            "packet_loss": net_ping.get("loss_percent", 0.0),
            "download_mbps": inet_speed.get("download_mbps"),
            "upload_mbps": inet_speed.get("upload_mbps"),
        }

        # Diagnostics suite
        dns_res = {}
        curl_res = {}
        mtr_res = {}
        ssl_res = {}
        tcp_res = {}
        gw_reachable = True

        if not (cancel_check and cancel_check()):
            try:
                dns_res = NetworkDiagnostics.run_dig("google.com", timeout=2.0)
                curl_res = NetworkDiagnostics.run_curl("https://www.google.com", timeout=3.0)
                tcp_res = NetworkDiagnostics.run_tcp_port_check("8.8.8.8", 443)
                gw_reachable = NetworkDiagnostics.is_gateway_reachable()
            except Exception:
                pass

        finished_at = get_utc_now()

        # Primary metrics for FarLink Edge
        dl_mbps = master_conn["bandwidth_mbps"] if master_conn["bandwidth_mbps"] is not None else internet_conn["download_mbps"]
        ul_mbps = master_conn["bandwidth_mbps"] if master_conn["bandwidth_mbps"] is not None else internet_conn["upload_mbps"]
        lat_ms = master_conn["latency_ms"] if master_conn["latency_ms"] is not None else internet_conn["latency_ms"]
        jit_ms = master_conn["jitter_ms"] if master_conn["jitter_ms"] is not None else internet_conn["jitter_ms"]
        loss_val = master_conn["packet_loss"] if master_conn["packet_loss"] is not None else internet_conn["packet_loss"]

        status = "success"
        error_msg = None
        if dl_mbps is None and lat_ms is None:
            status = "failed"
            dl_mbps = 0.0
            ul_mbps = 0.0
            loss_val = 100.0
            error_msg = "Edge master peer and internet unreachable"

        conn = NetworkDiagnostics.get_connection_type()

        return {
            "id": test_id,
            "test_type": "edge_dual",
            "trigger_type": trigger_type,
            "status": status,
            "error_message": error_msg,
            "started_at": started_at,
            "finished_at": finished_at,
            "rtc_time": started_at,
            "duration_seconds": round(time.time() - start_ts, 2),
            "download_mbps": dl_mbps,
            "upload_mbps": ul_mbps,
            "latency_ms": lat_ms,
            "jitter_ms": jit_ms,
            "packet_loss": loss_val,
            "dns_latency_ms": dns_res.get("dns_latency_ms"),
            "http_latency_ms": curl_res.get("http_latency_ms"),
            "mtr_hops": mtr_res.get("hops_count"),
            "mtr_max_rtt_ms": mtr_res.get("max_hop_rtt_ms"),
            "ssl_cert_days_remaining": ssl_res.get("days_remaining"),
            "tcp_port_status": tcp_res.get("status"),
            "gateway_reachable": gw_reachable,
            "connection_type": conn.get("type", "Ethernet"),
            "interface": conn.get("interface", "eth0"),
            "master_connection": master_conn,
            "internet_connection": internet_conn,
        }

