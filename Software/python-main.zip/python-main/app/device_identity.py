"""Device identity and hardware information handling."""
import uuid
import secrets
import string
import hashlib
from typing import Optional
from app.database import Database, get_utc_now
from app.logger import setup_logger

logger = setup_logger("device_identity")


def generate_claim_code(length: int = 8) -> str:
    """Generate a short user-friendly claim code (e.g. FL-A8X3-9K2)."""
    alphabet = string.ascii_uppercase + string.digits
    raw = "".join(secrets.choice(alphabet) for _ in range(length))
    return f"FL-{raw[:4]}-{raw[4:]}"


def get_mac_address() -> str:
    """Retrieve primary network MAC address with fallback."""
    try:
        import psutil
        for interface, addrs in psutil.net_if_addrs().items():
            if interface.startswith(("eth", "en", "wlan")):
                for addr in addrs:
                    if addr.family == psutil.AF_LINK or getattr(addr, "address", None):
                        mac = addr.address
                        if mac and len(mac.split(":")) == 6 and mac != "00:00:00:00:00:00":
                            return mac
    except ImportError:
        pass

    # Standard library fallback
    node = uuid.getnode()
    mac_hex = f"{node:012x}"
    return ":".join(mac_hex[i:i+2] for i in range(0, 12, 2))


def get_raspberry_pi_serial() -> str:
    """Retrieve authentic hardware serial number from Raspberry Pi or generate unique persistent hardware SN."""
    # 1. Raspberry Pi 5 / CM5 device-tree serial number
    for path in ["/proc/device-tree/serial-number", "/sys/firmware/devicetree/base/serial-number"]:
        try:
            with open(path, "r") as f:
                s = f.read().strip().strip("\x00").strip()
                if s and s != "0000000000000000":
                    return f"RPI-{s.upper()}"
        except Exception:
            pass

    # 2. Linux /proc/cpuinfo Serial (Standard Raspberry Pi 3/4/Zero)
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.lower().startswith("serial"):
                    parts = line.split(":")
                    if len(parts) >= 2:
                        s = parts[1].strip()
                        if s and s != "0000000000000000":
                            return f"RPI-{s.upper()}"
    except Exception:
        pass

    # 3. Derive from primary physical MAC address if valid
    mac = get_mac_address().replace(":", "").upper()
    if mac and mac != "000000000000":
        return f"RPI-{mac}"

    # 4. Fallback system node / random hex
    alphabet = string.ascii_uppercase + string.digits
    rand = "".join(secrets.choice(alphabet) for _ in range(8))
    return f"RPI-{rand}"


def get_hardware_fingerprint() -> str:
    """Retrieve unique hardware fingerprint from Raspberry Pi CM5 / Pi 5 (RP1/BCM2712)."""
    # 1. Raspberry Pi 5 / CM5 device-tree serial number
    for path in ["/proc/device-tree/serial-number", "/sys/firmware/devicetree/base/serial-number"]:
        try:
            with open(path, "r") as f:
                s = f.read().strip().strip("\x00")
                if s and s != "0000000000000000":
                    return f"pi-sn:{s}"
        except Exception:
            pass

    # 2. Linux /proc/cpuinfo Serial
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.lower().startswith("serial"):
                    parts = line.split(":")
                    if len(parts) >= 2:
                        s = parts[1].strip()
                        if s and s != "0000000000000000":
                            return f"cpu-sn:{s}"
    except Exception:
        pass

    # 3. Primary physical MAC address
    mac = get_mac_address()
    if mac and mac != "00:00:00:00:00:00":
        return f"mac:{mac}"

    # 4. Fallback system node
    return f"node:{uuid.getnode()}"


class DeviceIdentity:
    def __init__(self, db: Database, force_new: bool = False):
        self.db = db
        current_hw = get_hardware_fingerprint()
        stored_hw = self._get_state("hardware_fingerprint")

        # Detect if database was copied/cloned to a different physical Raspberry Pi
        if force_new or (stored_hw and stored_hw != current_hw):
            logger.warning(
                f"[DEVICE IDENTITY] Hardware difference detected! Stored: {stored_hw}, Current: {current_hw}. "
                "Generating fresh unique identity and claim code for this device..."
            )
            self.regenerate_identity(current_hw)
        else:
            if not stored_hw:
                self._set_state("hardware_fingerprint", current_hw)
            self.device_uuid = self._get_or_create_state("device_uuid", lambda: str(uuid.uuid4()))
            self.claim_code = self._get_or_create_state("claim_code", generate_claim_code)
            self.serial_number = self._get_or_create_state("serial_number", get_raspberry_pi_serial)

        self.mac_address: str = get_mac_address()

    def regenerate_identity(self, hw_fingerprint: Optional[str] = None) -> None:
        """Force generation of a new UUID, Serial Number, and Claim Code (guaranteed unique per physical device)."""
        hw = hw_fingerprint or get_hardware_fingerprint()
        new_uuid = str(uuid.uuid4())
        new_claim = generate_claim_code()
        new_sn = get_raspberry_pi_serial()

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM device_state WHERE key IN ('device_uuid', 'claim_code', 'device_token', 'device_status', 'hardware_fingerprint', 'serial_number')")
            now = get_utc_now()
            cursor.execute("INSERT INTO device_state (key, value, updated_at) VALUES ('hardware_fingerprint', ?, ?)", (hw, now))
            cursor.execute("INSERT INTO device_state (key, value, updated_at) VALUES ('device_uuid', ?, ?)", (new_uuid, now))
            cursor.execute("INSERT INTO device_state (key, value, updated_at) VALUES ('claim_code', ?, ?)", (new_claim, now))
            cursor.execute("INSERT INTO device_state (key, value, updated_at) VALUES ('serial_number', ?, ?)", (new_sn, now))
            cursor.execute("INSERT INTO device_state (key, value, updated_at) VALUES ('device_status', 'PENDING', ?)", (now,))

        self.device_uuid = new_uuid
        self.claim_code = new_claim
        self.serial_number = new_sn
        logger.info(f"[DEVICE IDENTITY] Fresh identity generated: SN={self.serial_number}, UUID={self.device_uuid}, ClaimCode={self.claim_code} (HW: {hw})")

    def _get_state(self, key: str) -> Optional[str]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM device_state WHERE key = ?", (key,))
            row = cursor.fetchone()
            return str(row["value"]) if row else None

    def _set_state(self, key: str, value: str) -> None:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO device_state (key, value, updated_at) VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                (key, value, get_utc_now()),
            )

    def _get_or_create_state(self, key: str, default_fn) -> str:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM device_state WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                return str(row["value"])
            new_value = default_fn()
            cursor.execute(
                "INSERT INTO device_state (key, value, updated_at) VALUES (?, ?, ?)",
                (key, new_value, get_utc_now()),
            )
            return str(new_value)

    def get_token(self) -> Optional[str]:
        return self._get_state("device_token")

    def set_token(self, token: str) -> None:
        self._set_state("device_token", token)

    def get_status(self) -> str:
        return self._get_state("device_status") or "PENDING"

    def set_status(self, status: str) -> None:
        self._set_state("device_status", status)
