export type DeviceEdgeMode = "Master" | "Slave" | "Standalone" | null;

export interface DeviceRoleInfo {
  isEdge: boolean;
  edgeMode: DeviceEdgeMode;
  label: string;
}

/**
 * Parses a device and its JSON config to determine whether it is a FarLink Edge
 * device and its operational role (Master, Slave, or Standalone).
 */
export function getDeviceRole(device: {
  type?: string | null;
  config?: string | null | Record<string, any>;
}): DeviceRoleInfo {
  let cfg: Record<string, any> = {};
  if (typeof device?.config === "string") {
    try {
      cfg = JSON.parse(device.config || "{}");
    } catch {
      cfg = {};
    }
  } else if (device?.config && typeof device.config === "object") {
    cfg = device.config;
  }

  const rawType = String(device?.type || "").toUpperCase();
  const cfgType = String(cfg.type || cfg.device_type || "").toUpperCase();
  const cfgMode = cfg.mode || cfg.device_mode;

  const isEdge =
    rawType.includes("EDGE") ||
    cfgType.includes("EDGE") ||
    cfgMode === "Master" ||
    cfgMode === "Slave";

  if (!isEdge) {
    return {
      isEdge: false,
      edgeMode: null,
      label: "FarLink Go",
    };
  }

  let edgeMode: DeviceEdgeMode = "Slave";
  if (cfgMode === "Master") {
    edgeMode = "Master";
  } else if (cfgMode === "Standalone") {
    edgeMode = "Standalone";
  } else if (cfgMode === "Slave") {
    edgeMode = "Slave";
  } else {
    // Default FarLink Edge is Slave unless specified
    edgeMode = "Slave";
  }

  return {
    isEdge: true,
    edgeMode,
    label: `FarLink Edge (${edgeMode})`,
  };
}
