import crypto from "crypto";
import { prisma } from "./db";

export function hashToken(t: string) {
  return crypto.createHash("sha256").update(t).digest("hex");
}

/** Autentikasi device dari Bearer token, X-Device-UUID header, atau URL params */
export async function authDevice(req: Request) {
  const h = req.headers.get("authorization") ?? "";
  const token = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  const deviceUuid = req.headers.get("x-device-uuid")?.trim();

  if (token) {
    const hashed = hashToken(token);
    const d = await prisma.device.findFirst({
      where: {
        OR: [
          { tokenHash: hashed },
          { tokenHash: token },
        ],
      },
    });
    if (d) return d;
  }

  if (deviceUuid) {
    const d = await prisma.device.findFirst({
      where: {
        OR: [
          { serialNumber: deviceUuid },
          { id: deviceUuid },
          { name: { contains: deviceUuid } },
          { config: { contains: deviceUuid } },
        ],
      },
    });
    if (d) return d;
  }

  try {
    const url = new URL(req.url);
    const qUuid = url.searchParams.get("device_uuid");
    const qToken = url.searchParams.get("token");
    if (qToken) {
      const d = await prisma.device.findFirst({ where: { tokenHash: hashToken(qToken) } });
      if (d) return d;
    }
    if (qUuid) {
      const d = await prisma.device.findFirst({
        where: {
          OR: [
            { serialNumber: qUuid },
            { id: qUuid },
            { name: { contains: qUuid } },
            { config: { contains: qUuid } },
          ],
        },
      });
      if (d) return d;
    }
  } catch {}

  return null;
}
