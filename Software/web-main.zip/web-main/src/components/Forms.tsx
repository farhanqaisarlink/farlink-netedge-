"use client";

import { useActionState, useEffect, useState } from "react";
import { Plus, X } from "lucide-react";
import { saveCompany, saveDevice } from "@/lib/actions";

type Company = { id: string; name: string; contact?: string | null; address?: string | null };

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="card modal" onClick={(e) => e.stopPropagation()}>
        <div className="card-head">
          <h3>{title}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Close"><X size={16} /></button>
        </div>
        <div className="card-body">{children}</div>
      </div>
    </div>
  );
}

export function CompanyButton({ company, label }: { company?: Company; label?: string }) {
  const [open, setOpen] = useState(false);
  const [state, action, pending] = useActionState(saveCompany, null);
  useEffect(() => { if (state?.ok) setOpen(false); }, [state]);
  return (
    <>
      <button id={company ? "edit-company" : "add-company"} className={company ? "btn btn-sm" : "btn btn-primary"} onClick={() => setOpen(true)}>
        {!company && <Plus size={16} />} {label ?? (company ? "Edit" : "Add Company")}
      </button>
      {open && (
        <Modal title={company ? "Edit Company" : "New Company"} onClose={() => setOpen(false)}>
          <form action={action} className="stack">
            {state?.error && <div className="alert alert-error">{state.error}</div>}
            {company && <input type="hidden" name="id" value={company.id} />}
            <div className="field"><label>Company name</label><input name="name" className="input" required defaultValue={company?.name} /></div>
            <div className="field"><label>Contact</label><input name="contact" className="input" defaultValue={company?.contact ?? ""} /></div>
            <div className="field"><label>Address</label><input name="address" className="input" defaultValue={company?.address ?? ""} /></div>
            <button className="btn btn-primary" disabled={pending}>Save</button>
          </form>
        </Modal>
      )}
    </>
  );
}

type Device = { id: string; name: string; serialNumber: string; type: string; companyId: string | null; ipAddress?: string | null; gatewayIp: string | null };

export function DeviceButton({
  companies,
  device,
  defaultCompany,
  fixedSerialNumber,
  prefillIp,
  prefillType,
  label,
  buttonClass,
  buttonIcon,
}: {
  companies: Company[];
  device?: Device;
  defaultCompany?: string;
  fixedSerialNumber?: string;
  prefillIp?: string;
  prefillType?: string;
  label?: React.ReactNode;
  buttonClass?: string;
  buttonIcon?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [state, action, pending] = useActionState(saveDevice, null);
  useEffect(() => { if (state?.ok && !state.token) setOpen(false); }, [state]);

  const activeSn = fixedSerialNumber || device?.serialNumber || "";
  const isSnLocked = !!fixedSerialNumber || !!device;

  const defaultName = device?.name ?? (fixedSerialNumber ? `FarLink-${fixedSerialNumber.replace(/^RPI-/, "").slice(0, 8)}` : "");

  const [devType, setDevType] = useState<string>(prefillType ?? device?.type ?? "FARLINK_GO");
  const [devMode, setDevMode] = useState<string>("Slave");

  return (
    <>
      <button
        id={device ? "edit-device" : fixedSerialNumber ? `register-${fixedSerialNumber}` : "add-device"}
        className={buttonClass ?? (device ? "btn btn-sm" : "btn btn-primary")}
        onClick={() => setOpen(true)}
      >
        {buttonIcon !== undefined ? buttonIcon : (!device && <Plus size={16} />)}{" "}
        {label ?? (device ? "Edit" : fixedSerialNumber ? `Register Device (${fixedSerialNumber})` : "Add Device")}
      </button>
      {open && (
        <Modal
          title={device ? "Edit Device" : fixedSerialNumber ? "Register Connected Device" : "Register Device"}
          onClose={() => setOpen(false)}
        >
          {state?.token ? (
            <div className="stack">
              <div className="alert alert-ok">{state.message}</div>
              <div className="field"><label>Device token</label><input className="input mono" readOnly value={state.token} onFocus={(e) => e.target.select()} /></div>
              <p className="muted" style={{ fontSize: 12.5 }}>The device is now registered and authenticated with FarLink Cloud.</p>
              <button className="btn btn-primary" onClick={() => setOpen(false)}>Done</button>
            </div>
          ) : (
            <form action={action} className="stack">
              {state?.error && <div className="alert alert-error">{state.error}</div>}
              {device && <input type="hidden" name="id" value={device.id} />}
              <div className="form-grid">
                <div className="field">
                  <label>Device Name</label>
                  <input name="name" className="input" required defaultValue={defaultName} placeholder="e.g. FarLink-001" />
                </div>
                <div className="field">
                  <label style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span>Serial Number</span>
                    {isSnLocked && (
                      <span className="badge b-online mono" style={{ fontSize: 10, padding: "2px 6px" }}>
                        Hardware Locked
                      </span>
                    )}
                  </label>
                  <input
                    name="serialNumber"
                    className="input mono"
                    required
                    readOnly={isSnLocked}
                    defaultValue={activeSn}
                    style={isSnLocked ? { background: "rgba(255,255,255,0.05)", cursor: "not-allowed" } : undefined}
                  />
                  {isSnLocked && (
                    <p className="dim" style={{ fontSize: 11.5, marginTop: 4 }}>
                      Hardware serial number cannot be changed because it is permanently bound to this physical Raspberry Pi.
                    </p>
                  )}
                </div>
                <div className="field">
                  <label>Device Model / Type</label>
                  <select
                    name="type"
                    className="select"
                    value={devType}
                    onChange={(e) => setDevType(e.target.value)}
                  >
                    <option value="FARLINK_GO">FarLink Go (Portable Network Probe)</option>
                    <option value="FARLINK_EDGE">FarLink Edge (Dual-Engine / Master-Slave)</option>
                  </select>
                </div>
                {devType === "FARLINK_EDGE" && (
                  <div className="field">
                    <label>FarLink Edge Role</label>
                    <select
                      name="mode"
                      className="select"
                      value={devMode}
                      onChange={(e) => setDevMode(e.target.value)}
                    >
                      <option value="Slave">Slave (Probes & Tests to Master)</option>
                      <option value="Master">Master (1 per Company · Central Hub)</option>
                    </select>
                    {devMode === "Master" && (
                      <p className="dim" style={{ fontSize: 11.5, color: "#c084fc", marginTop: 4 }}>
                        Aturan: 1 Company = 1 Master. Jika sudah ada Master lain di company ini, role Master akan dialihkan ke device ini.
                      </p>
                    )}
                  </div>
                )}
                <div className="field">
                  <label>Assign to Customer Company</label>
                  <select name="companyId" className="select" defaultValue={device?.companyId ?? defaultCompany ?? ""}>
                    <option value="">— Unassigned —</option>
                    {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="field">
                  <label>IP Address</label>
                  <input
                    name="ipAddress"
                    className="input mono"
                    defaultValue={device?.ipAddress ?? prefillIp ?? ""}
                    placeholder="192.168.1.8"
                  />
                </div>
                <div className="field">
                  <label>Gateway IP</label>
                  <input
                    name="gatewayIp"
                    className="input mono"
                    defaultValue={device?.gatewayIp ?? (prefillIp ? prefillIp.replace(/\.\d+$/, ".1") : "")}
                    placeholder="192.168.1.1"
                  />
                </div>
              </div>
              <div className="row" style={{ justifyContent: "flex-end", marginTop: 8 }}>
                <button type="button" className="btn" onClick={() => setOpen(false)}>Cancel</button>
                <button className="btn btn-primary" disabled={pending}>
                  {fixedSerialNumber ? "Register & Activate Device" : "Save"}
                </button>
              </div>
            </form>
          )}
        </Modal>
      )}
    </>
  );
}
