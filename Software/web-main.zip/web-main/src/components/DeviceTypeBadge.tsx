import { Crown, Link2, Radio, Server } from "lucide-react";
import { getDeviceRole } from "@/lib/device-utils";

export function DeviceTypeBadge({
  device,
  showIcon = true,
}: {
  device: { type?: string | null; config?: string | null | Record<string, any> };
  showIcon?: boolean;
}) {
  const role = getDeviceRole(device);

  if (!role.isEdge) {
    return (
      <span className="badge b-unknown" title="FarLink Go (Portable Network Probe)">
        {showIcon && <Radio size={11} style={{ opacity: 0.8 }} />}
        <span>FarLink Go</span>
      </span>
    );
  }

  if (role.edgeMode === "Master") {
    return (
      <span
        className="badge b-master"
        title="FarLink Edge Master (Central Hub for Company)"
        style={{
          boxShadow: "0 0 10px rgba(192, 132, 252, 0.2)",
        }}
      >
        <span className="dot" />
        {showIcon && <Crown size={12} style={{ color: "#e879f9" }} />}
        <span>FarLink Edge · Master</span>
      </span>
    );
  }

  if (role.edgeMode === "Slave") {
    return (
      <span
        className="badge b-slave"
        title="FarLink Edge Slave (Probes & Tests to Master)"
      >
        <span className="dot" />
        {showIcon && <Link2 size={12} />}
        <span>FarLink Edge · Slave</span>
      </span>
    );
  }

  return (
    <span className="badge b-standalone" title="FarLink Edge Standalone">
      {showIcon && <Server size={11} />}
      <span>FarLink Edge · Standalone</span>
    </span>
  );
}
