import { NextResponse } from "next/server";
import { Client } from "ssh2";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface SshParams {
  host?: string;
  port?: number;
  username?: string;
  password?: string;
  privateKey?: string;
  command?: string;
  action?: "test" | "exec";
  saveCredentials?: boolean;
}

function runSshCommand(
  config: { host: string; port: number; username: string; password?: string; privateKey?: string },
  command: string,
  timeoutMs: number = 20000,
): Promise<{ stdout: string; stderr: string; code: number; latencyMs: number }> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let stdout = "";
    let stderr = "";
    const start = performance.now();
    let timer: NodeJS.Timeout;

    const cleanup = () => {
      clearTimeout(timer);
      try {
        conn.end();
      } catch {}
    };

    timer = setTimeout(() => {
      cleanup();
      reject(new Error(`SSH execution timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    conn
      .on("ready", () => {
        conn.exec(command, (err, stream) => {
          if (err) {
            cleanup();
            return reject(err);
          }
          stream
            .on("close", (code: number) => {
              const latencyMs = Math.round(performance.now() - start);
              cleanup();
              resolve({ stdout, stderr, code: code ?? 0, latencyMs });
            })
            .on("data", (data: Buffer) => {
              stdout += data.toString("utf-8");
            })
            .stderr.on("data", (data: Buffer) => {
              stderr += data.toString("utf-8");
            });
        });
      })
      .on("keyboard-interactive", (_name, _instructions, _lang, prompts, finish) => {
        if (prompts.length > 0 && config.password) {
          finish([config.password]);
        } else {
          finish([]);
        }
      })
      .on("error", (err: any) => {
        cleanup();
        const msg = String(err.message || "");
        if (err.level === "client-authentication" || msg.toLowerCase().includes("authentication") || msg.includes("All configured authentication methods failed")) {
          reject(new Error(`Authentication failed: Incorrect password or username for ${config.username}@${config.host}`));
        } else if (msg.toLowerCase().includes("handshake") || msg.toLowerCase().includes("timed out")) {
          reject(new Error(`SSH connection timed out. Please check if IP ${config.host} is reachable and password is correct.`));
        } else {
          reject(err);
        }
      })
      .connect({
        host: config.host,
        port: config.port,
        username: config.username,
        password: config.password || undefined,
        privateKey: config.privateKey || undefined,
        tryKeyboard: true,
        readyTimeout: 12000,
        keepaliveInterval: 5000,
      });
  });
}

function testSshConnection(
  config: { host: string; port: number; username: string; password?: string; privateKey?: string },
  timeoutMs: number = 10000,
): Promise<{ success: boolean; latencyMs: number; banner?: string }> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    const start = performance.now();
    let banner = "";
    let timer: NodeJS.Timeout;

    const cleanup = () => {
      clearTimeout(timer);
      try {
        conn.end();
      } catch {}
    };

    timer = setTimeout(() => {
      cleanup();
      reject(new Error(`SSH connection timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    conn
      .on("banner", (msg: string) => {
        banner = msg;
      })
      .on("ready", () => {
        const latencyMs = Math.round(performance.now() - start);
        cleanup();
        resolve({ success: true, latencyMs, banner });
      })
      .on("keyboard-interactive", (_name, _instructions, _lang, prompts, finish) => {
        if (prompts.length > 0 && config.password) {
          finish([config.password]);
        } else {
          finish([]);
        }
      })
      .on("error", (err: any) => {
        cleanup();
        const msg = String(err.message || "");
        if (err.level === "client-authentication" || msg.toLowerCase().includes("authentication") || msg.includes("All configured authentication methods failed")) {
          reject(new Error(`Authentication failed: Incorrect password or username for ${config.username}@${config.host}`));
        } else if (msg.toLowerCase().includes("handshake") || msg.toLowerCase().includes("timed out")) {
          reject(new Error(`SSH connection timed out. Please check if IP ${config.host} is reachable and password is correct.`));
        } else {
          reject(err);
        }
      })
      .connect({
        host: config.host,
        port: config.port,
        username: config.username,
        password: config.password || undefined,
        privateKey: config.privateKey || undefined,
        tryKeyboard: true,
        readyTimeout: timeoutMs,
      });
  });
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const s = await requireSession();
    const { id } = await params;
    const body: SshParams = await req.json().catch(() => ({}));

    const device = await prisma.device.findUnique({ where: { id } });
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    let devConfig: Record<string, any> = {};
    try {
      devConfig = JSON.parse(device.config || "{}");
    } catch {}

    const savedSsh = devConfig.ssh || {};

    const host = (body.host || savedSsh.host || device.ipAddress || "").trim();
    const port = Number(body.port || savedSsh.port || 22);
    const username = (body.username || savedSsh.username || "farlink").trim();
    const password = body.password !== undefined ? body.password : (savedSsh.password || "");
    const privateKey = body.privateKey !== undefined ? body.privateKey : (savedSsh.privateKey || "");

    if (!host) {
      return NextResponse.json(
        { error: "Device host IP not specified. Please enter an IP address in SSH settings." },
        { status: 400 },
      );
    }

    if (!username) {
      return NextResponse.json({ error: "SSH username not specified." }, { status: 400 });
    }

    if (!password && !privateKey) {
      return NextResponse.json({
        ok: false,
        error: `Password SSH diperlukan untuk menghubungkan ke ${username}@${host}. Silakan masukkan password di panel atas.`,
        needPassword: true,
      }, { status: 400 });
    }

    // Optionally save credentials in device config
    if (body.saveCredentials) {
      const updatedConfig = JSON.stringify({
        ...devConfig,
        ssh: {
          host,
          port,
          username,
          password: password ? password : savedSsh.password,
          privateKey: privateKey ? privateKey : savedSsh.privateKey,
          savedAt: new Date().toISOString(),
        },
      });
      await prisma.device.update({
        where: { id },
        data: { config: updatedConfig },
      });
    }

    const sshConnConfig = { host, port, username, password, privateKey };

    // Action: Test Connection
    if (body.action === "test") {
      try {
        const res = await testSshConnection(sshConnConfig, 8000);
        return NextResponse.json({
          ok: true,
          action: "test",
          host,
          port,
          username,
          latencyMs: res.latencyMs,
          banner: res.banner || "SSH-2.0 OpenSSH",
          message: `SSH connection to ${username}@${host}:${port} successful (${res.latencyMs}ms)`,
        });
      } catch (err: any) {
        return NextResponse.json({
          ok: false,
          action: "test",
          host,
          port,
          username,
          error: `Failed to connect to ${username}@${host}:${port}: ${err.message}`,
        });
      }
    }

    // Action: Exec Command
    const command = (body.command || "uname -a").trim();
    if (!command) {
      return NextResponse.json({ error: "SSH command cannot be empty." }, { status: 400 });
    }

    try {
      const res = await runSshCommand(sshConnConfig, command, 20000);

      // Audit log the SSH execution
      await prisma.auditLog.create({
        data: {
          userId: s.sub,
          action: "DEVICE_SSH_EXEC",
          target: device.name,
          detail: JSON.stringify({
            host,
            port,
            command: command.length > 200 ? command.slice(0, 200) + "..." : command,
            code: res.code,
            latencyMs: res.latencyMs,
          }),
        },
      });

      return NextResponse.json({
        ok: true,
        action: "exec",
        command,
        host,
        port,
        username,
        stdout: res.stdout,
        stderr: res.stderr,
        code: res.code,
        latencyMs: res.latencyMs,
      });
    } catch (err: any) {
      return NextResponse.json({
        ok: false,
        action: "exec",
        command,
        host,
        port,
        username,
        error: `SSH execution failed: ${err.message}`,
      });
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
